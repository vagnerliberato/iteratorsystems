GeoPostcodes, Geographic databases
Copyright (C) 2010 GeoPostcodes Ltd
EMail : info@geopostcodes.com


========================
= WWW.GEOPOSTCODES.COM =
========================

Thank you for buying a GeoPostcodes product, we appreciate your business. Hereafter you will find some technical information on GeoPostcodes databases and how to import these files in your application.


==================
Database structure
==================

All our files are based on the same structure, however and depending on the country, some fields may remain void.

 +---------+---------+------------------------+
 |Champ    |Type     |Information             |
 +---------+---------+------------------------+
 |Country  |Char(2)  |ISO country code        |
 |Language |Char(2)  |ISO language code       |
 |ID       |Long     |Unique identifier       |
 |RegISO2  |Char(6)  |ISO-2 region code       |
 |Region1  |Char(60) |Administrative region 1 |
 |Region2  |Char(60) |Administrative region 2 |
 |Region3  |Char(60) |Administrative region 3 |
 |Region4  |Char(60) |Administrative region 4 |
 |Postcode |Char(10) |ZIP or Postal code      |
 |City     |Char(60) |Locality name           |
 |Area1    |Char(80) |Street, block, district |
 |Area2    |Char(80) |Street, block, district |
 |Lat      |Double   |Geographic latitude     |
 |Lng      |Double   |Geographic longitude    |
 |TZ       |Char(30) |Time zone (Olson code)  |
 |UTC      |Char(10) |Local time              |
 |DST      |Char(1)  |Daylight saving time    |
 +---------+---------+------------------------+



=======================
Available Files Formats
=======================

*.csv : Text delimited
*.xls : Excel spreadsheet (limited to 65536 rows, see below)
*.asc : Unformatted ASCII Text (no accented chars, http://www.geopostcodes.com/encoding)
*.xml : XML encoding
*.sql : MySQL database
*.dat : SQL Server data file



Microsoft Excel (.xls)
-----------------------

The .xls format is compatible with all Excel versions but is limited to 65536 rows and may not be working for non-latin chars.
If you have Excel 2007 or 2010 you can use the .csv file to get up to 1 million rows.
 
In case of problem, you can import the .csv file manually :
- In the File|Open menu, select your text file (GeoPC_xx.csv)
- In import wizard, select "Delimited" data type and "65001 : Unicode (UTF-8)" encoding
- Click on Next, select Semicolon as delimiter and " as text qualifier and click on the Finish button

Maximum number of rows:
- Excel 2003 and earlier : 65536 rows (.xls)
- Excel 2007 : 1048576 rows (.csv)


Microsoft Access (.mdb)
-----------------------

We do not provide native Access databases, however it is really easy to import a GeoPostcodes database in Access, here is how to do :

- Open or create a new Access database
- Go to File|Get External Data|Import in the menu, select your file (GeoPC_xx.csv)
- Select Delimited, click on Advanced and select Unicode (UTF-8) as Code Page
- Click Next, select Semicolon as delimiter and " as Text qualifier
- Tick First row contains field names and click on Finish


Text delimited (.csv)
---------------------

This is the most common format, most applications can import text delimited files. Fields are separated by a semicolon, text are enclosed by double quotes ("). UTF-8 encoding.


Unformatted ASCII Text (.asc)
-----------------------------

The format of this file is the same than above .csv but without accented or special characters used in foreign languages. You will find more information on the ASCII format on our website : http://www.geopostcodes.com/encoding


XML encoding (.xml)
------------------------

Another common format, can be used for website development.


MySQL database (.sql)
---------------------

The .sql file contains both queries and data to import your GeoPostcodes file in a MySQL database.

** phpMyAdmin :

Click on the Import tab, select your GeoPC_xx.sql file and utf8 as Character set.

** Command line :

mysql> source GeoPC_xx.sql

** If you prefer create the table and import the data manually, here is the query :

DROP TABLE IF EXISTS GeoPC;

CREATE TABLE GeoPC (
  Country varchar(2) NOT NULL,
  Language varchar(2) NOT NULL,
  ID bigint(20) NOT NULL,
  RegISO2 varchar(6) NOT NULL,
  Region1 varchar(60) NOT NULL,
  Region2 varchar(60) NOT NULL,
  Region3 varchar(60) NOT NULL,
  Region4 varchar(60) NOT NULL,
  ZIP varchar(10) NOT NULL,
  City varchar(60) NOT NULL,
  Area1 varchar(80) NOT NULL,
  Area2 varchar(80) NOT NULL,
  Lat double NOT NULL,
  Lng double NOT NULL,
  TZ varchar(30) NOT NULL,
  UTC varchar(10) NOT NULL,
  DST varchar(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOAD DATA INFILE '/path/GeoPC_xx.csv' INTO TABLE yourdb.GeoPC FIELDS TERMINATED BY ';' ENCLOSED BY '"' ESCAPED BY '\\' LINES TERMINATED BY '\r\n';
  

Microsoft SQL Server (.dat)
---------------------------

To import GeoPostcodes in Microsoft SQL Server, you need to use the GeoPC_xx.dat file with the BULK INSERT command :

CREATE TABLE [GeoPC] (
   [Country] [nvarchar](2) NULL,
   [Language] [nvarchar](2) NULL,
   [ID] [bigint] NULL,
   [RegISO2] [nvarchar](6) NULL,
   [Region1] [nvarchar](60) NULL,
   [Region2] [nvarchar](60) NULL,
   [Region3] [nvarchar](60) NULL,
   [Region4] [nvarchar](60) NULL,
   [ZIP] [nvarchar](10) NULL,
   [City] [nvarchar](60) NULL,
   [Area1] [nvarchar](80) NULL,
   [Area2] [nvarchar](80) NULL,
   [Lat] [float] NULL,
   [Lng] [float] NULL,
   [TZ] [nvarchar](30) NULL,
   [UTC] [nvarchar](10) NULL,
   [DST] [nvarchar](1) NULL
)
GO

BULK INSERT GeoPC FROM 'Path\GeoPC_xx.dat' WITH (FIELDTERMINATOR = ';', DATAFILETYPE = 'widechar')




--
Copyright (C) 2010 GeoPostcodes Ltd

GeoPostcodes Ltd
info@geopostcodes.com
Harley Street 29
London W1G 9QR
United Kingdom
